export interface ValidationResultEntry
{
    ValidationMessage: string;
    ValidationTarget: string;
}