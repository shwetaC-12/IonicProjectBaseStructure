import { Injector } from '@angular/core';

export class ServiceInjector
{
    public static AppInjector: Injector;
}