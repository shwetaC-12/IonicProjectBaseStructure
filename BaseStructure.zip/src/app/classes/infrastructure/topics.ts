export class Topics {
    public static ClientToServerRequest: string = "ClientToServerRequest";
}