export interface SystemUserRepeatLoginConfirmationRequest
{
    Ref: string;
    ConfirmationToken: string;
}