export interface SystemUserLoginRequest
{
    Ref: number;
    UserName: string;
    Password: string;
    RequestingIPAddress: string;
}