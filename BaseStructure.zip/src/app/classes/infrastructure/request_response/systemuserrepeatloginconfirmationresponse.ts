export interface SystemUserRepeatLoginConfirmationResponse
{
    Ref: number;
    ConfirmationToken: string;
}