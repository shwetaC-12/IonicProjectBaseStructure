export interface AllocateProcessTokensResponse
{
    ProcessTokens: number[];
}
