export interface SystemUserLogoutRequest
{
    IPAddress: string;
    Token: number;
}