export const nameofFactory = <T>() => (name: keyof T) => name;
